﻿using System.Windows;
using System.Windows.Controls;
using System.Collections.Generic;
using Microsoft.Maps.MapControl;

namespace CustomToolTip
{
    public partial class MainPage : UserControl
    {
        private MapLayer pushPinLayer;

        public MainPage()
        {
            InitializeComponent();
            base.Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            pushPinLayer = new MapLayer() { Name = "PushPinLayer" };
            MyMap.Children.Add(pushPinLayer);

            List<PushPinLocation> locationList = LoadLocations();
            foreach (PushPinLocation pin in locationList)
            {
                AddPushpin(pin.PushPinLat, pin.PushPinLon, pin.PushPinName, pin.PushPinDescription, pin.PushPinImageUrl);
            }
        }

        private List<PushPinLocation> LoadLocations()
        {
            List<PushPinLocation> locationList = new List<PushPinLocation>();

            locationList.Add(new PushPinLocation { PushPinLat = 40, PushPinLon = -95, PushPinName = "Location 1", PushPinDescription = "Location 1 description goes here.", PushPinImageUrl = "Images/1.jpg" });
            locationList.Add(new PushPinLocation { PushPinLat = 20, PushPinLon = 28, PushPinName = "Location 2", PushPinDescription = "Location 2 description goes here.", PushPinImageUrl = "Images/2.jpg" });
            locationList.Add(new PushPinLocation { PushPinLat = -20, PushPinLon = 105, PushPinName = "Location 3", PushPinDescription = "Location 3 description goes here.", PushPinImageUrl = "Images/3.jpg" });
            locationList.Add(new PushPinLocation { PushPinLat = -30, PushPinLon = 125, PushPinName = "Location 4", PushPinDescription = "Location 4 description goes here.", PushPinImageUrl = "Images/4.jpg" });
            return locationList;
        }

        private void AddPushpin(double latitude, double longitude, string toolTipTitle, string toolTipDesc, string toolTipImageUrl)
        {
            Pushpin pushpin = new Pushpin() { Title = toolTipTitle, Description = toolTipDesc, ImageUrl=toolTipImageUrl };
            pushPinLayer.AddChild(pushpin, new Location(latitude, longitude), PositionOrigin.Center);

            ToolTipService.SetToolTip(pushpin, new ToolTip()
            {
                DataContext = pushpin,
                Style = Application.Current.Resources["CustomTooltipStyle"] as Style
            });
        }
    }

    public partial class Pushpin : Microsoft.Maps.MapControl.Pushpin
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
    }

    public class PushPinLocation
    {
        public double PushPinLat { get; set; }
        public double PushPinLon { get; set; }
        public string PushPinName { get; set; }
        public string PushPinDescription { get; set; }
        public string PushPinImageUrl { get; set; }
    }
}
