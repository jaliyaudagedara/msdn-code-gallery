﻿using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Controls.DataVisualization.Charting;

namespace SilverlightApplication1
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            svcCubeConnector.CubeConnectorClient client = new svcCubeConnector.CubeConnectorClient();

            client.GetDataCompleted += client_GetDataCompleted;
            client.GetDataAsync("SELECT NON EMPTY { [Measures].[AMOUNT] } ON COLUMNS, NON EMPTY { ([Account Type].[ACCOUNT DESC].[ACCOUNT DESC].ALLMEMBERS ) } DIMENSION PROPERTIES MEMBER_CAPTION ON ROWS FROM [JetWingBI]");
        }

        void client_GetDataCompleted(object sender, svcCubeConnector.GetDataCompletedEventArgs e)
        {
            IEnumerable<Dictionary<string, Object>> result = e.Result;
            List<ChartClass> chartCollection = new List<ChartClass>();
            object seriesName;
            object seriesValue;

            foreach (Dictionary<String, Object> _item in result)
            {
                // I am querying Dictionary with the Key
                _item.TryGetValue("[Account Type].[ACCOUNT DESC].[ACCOUNT DESC].[MEMBER_CAPTION]", out seriesName);
                _item.TryGetValue("[Measures].[AMOUNT]", out seriesValue);

                chartCollection.Add(new ChartClass { SeriesName = seriesName.ToString(), SeriesValue = Convert.ToDouble(seriesValue) });
            }

            // you can also set chart properties from code behind
            //((ColumnSeries)MyChart.Series[0]).DependentValueBinding = new System.Windows.Data.Binding("SeriesValue");
            //((ColumnSeries)MyChart.Series[0]).IndependentValueBinding = new System.Windows.Data.Binding("SeriesName");

            ((ColumnSeries)MyChart.Series[0]).ItemsSource = chartCollection;
        }
    }

    public class ChartClass
    {
        public string SeriesName { get; set; }
        public double SeriesValue { get; set; }
    }
}
