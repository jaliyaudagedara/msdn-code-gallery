﻿using System.Collections.Generic;
using System.ServiceModel;

namespace SilverlightApplication1.Web
{
    [ServiceContract]
    public interface ICubeConnector
    {
        [OperationContract]
        IEnumerable<Dictionary<string, object>> GetData(string query);
    }
}
