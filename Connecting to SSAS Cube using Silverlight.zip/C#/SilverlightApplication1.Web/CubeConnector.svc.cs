﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.AnalysisServices.AdomdClient;

namespace SilverlightApplication1.Web
{
    public class CubeConnector : ICubeConnector
    {
        public IEnumerable<Dictionary<string, object>> GetData(string query)
        {
            var table = GetDataTable(query);
            var columns = table.Columns.Cast<DataColumn>();
            return table.AsEnumerable().Select(r => columns.Select(c => new { Column = c.ColumnName, Value = r[c.ColumnName] })
                             .ToDictionary(i => i.Column, i => i.Value != DBNull.Value ? i.Value : null));
        }

        private DataTable GetDataTable(string query)
        {
            AdomdConnection conn = new AdomdConnection("Data Source=localhost; Catalog=JetWIngBI");
            AdomdDataAdapter adapter = new AdomdDataAdapter();
            adapter.SelectCommand = new AdomdCommand(query, conn);
            var table = new DataTable();
            conn.Open();

            try
            {
                adapter.Fill(table);
            }
            finally
            {
                conn.Close();
            }
            return table;
        }
    }
}
