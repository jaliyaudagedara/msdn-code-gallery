﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelToDatabaseApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"D:\SampleExcelFile.xlsx";
            DataSet ds = ReadToDataSet(filePath, "MyTable");

            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=MyTestDB;Integrated Security=True");
            PushDataSetToDatabase(conn, ds);
        }

        public static DataSet ReadToDataSet(string filePath, string tableName)
        {
            DataSet ds = new DataSet();
            OleDbCommand cmd = new OleDbCommand();
            OleDbDataAdapter adapter = new OleDbDataAdapter();

            // "HDR=Yes;" indicates that the first row contains columnnames. 
            // "HDR=No;" indicates the opposite.
            // MEX=1 is a safer way to retrieve data for mixed data columns
            // http://www.connectionstrings.com/ace-oledb-12-0/
            OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties='Excel 12.0;HDR=YES;IMEX=1;';");

            try
            {
                conn.Open();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;

                // to select all the columns
                //cmd.CommandText = "SELECT * FROM [MySheet$]";

                // I am only selecting some columns
                cmd.CommandText = "SELECT FirstName, LastName, Department FROM [MySheet$]";

                adapter = new OleDbDataAdapter(cmd);
                adapter.Fill(ds, tableName);
                return ds;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        public static void PushDataSetToDatabase(SqlConnection conn, DataSet ds)
        {
            try
            {
                foreach (DataTable dt in ds.Tables)
                {
                    if (!CheckWhetherTableExists(conn, dt.TableName))
                    {
                        CreateTableInDatabase(conn, dt);
                    }

                    conn.Open();
                    using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conn))
                    {
                        bulkcopy.DestinationTableName = dt.TableName;
                        bulkcopy.WriteToServer(dt);
                    }
                }
            }
            catch (Exception ex)
            {
                
            }
            finally
            {
                conn.Close();
            }
        }

        private static bool CheckWhetherTableExists(SqlConnection conn, string tableName)
        {
            bool isExist = false;
            SqlCommand cmd;
            try
            {
                conn.Open();
                cmd = new SqlCommand("SELECT * FROM sysobjects where name = '" + tableName + "'", conn);
                isExist = cmd.ExecuteScalar() == null ? false : true;
                return isExist;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return true;
        }

        private static void CreateTableInDatabase(SqlConnection conn, DataTable dt)
        {
            bool isExist = false;
            SqlCommand cmd;
            try
            {
                conn.Open();
                foreach (DataColumn dc in dt.Columns)
                {
                    if (!isExist)
                    {
                        cmd = new SqlCommand("CREATE TABLE " + dt.TableName + " (" + dc.ColumnName + " varchar(MAX))", conn);
                        cmd.ExecuteNonQuery();
                        isExist = true;
                    }
                    else
                    {
                        cmd = new SqlCommand("ALTER TABLE " + dt.TableName + " ADD " + dc.ColumnName + " varchar(MAX)", conn);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
        }
    }
}
