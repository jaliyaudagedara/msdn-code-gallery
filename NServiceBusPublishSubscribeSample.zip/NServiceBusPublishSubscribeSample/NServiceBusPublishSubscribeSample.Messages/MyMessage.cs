﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace NServiceBusPublishSubscribeSample.Messages
{
    public class MyMessage 
    {
        public string Message { get; set; }
    }
}
