﻿using NServiceBus;
using NServiceBusPublishSubscribeSample.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NServiceBusPublishSubscribeSample.Publisher
{
    public class MyTask : IWantToRunWhenBusStartsAndStops
    {
        public IBus Bus { get; set; }

        public void Start()
        {
            Bus.Publish(new MyMessage()
            {
                Message = "Hello World!"
            });
            Console.WriteLine("Published a message.");
        }

        public void Stop()
        {

        }
    }
}
