﻿using NServiceBus;
using NServiceBusPublishSubscribeSample.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NServiceBusPublishSubscribeSample.Subscriber
{
    public class MessageSubscriber : IHandleMessages<MyMessage>
    {
        public void Handle(MyMessage message)
        {
            Console.WriteLine(message.Message);
        }
    }
}
