﻿using System;
using System.IdentityModel.Selectors;
using System.ServiceModel.Security;

namespace WcfService1
{
    public class ServiceAuthenticator : UserNamePasswordValidator
    {
        public override void Validate(string userName, string password)
        {
            if (null == userName || null == password)
            {
                throw new ArgumentNullException();
            }

            if (!(userName == "username" && password == "password"))
            {
                throw new MessageSecurityException("Unknown Username or Password");
            }
        }
    }
}