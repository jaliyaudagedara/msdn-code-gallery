﻿using System;
using ConsoleApplication1.ServiceReference1;
using System.ServiceModel.Security;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Service1Client c = new Service1Client();
                c.ClientCredentials.UserName.UserName = "username";
                c.ClientCredentials.UserName.Password = "password";
                c.ClientCredentials.ServiceCertificate.Authentication.CertificateValidationMode = X509CertificateValidationMode.None;
                Console.WriteLine(c.GetData(5));
            }
            catch (MessageSecurityException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
    }
}
