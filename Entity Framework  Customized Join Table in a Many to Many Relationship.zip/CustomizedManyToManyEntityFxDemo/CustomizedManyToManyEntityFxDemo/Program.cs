﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomizedManyToManyEntityFxDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            using (MyDbContext context = new MyDbContext())
            {
                context.Persons.Add(new Person() { Id = 1, Name = "Jaliya Udagedara" });
                context.SaveChanges();
            }
        }
    }

    public class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public virtual ICollection<PersonHobbies> Hobbies { get; set; }
    }

    public class Hobby
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public virtual ICollection<PersonHobbies> Persons { get; set; }
    }

    public class PersonHobbies
    {
        public int Person_Id { get; set; }
        public int Hobby_Id { get; set; }
        public virtual Person Person { get; set; }
        public virtual Hobby Hobby { get; set; }
        public bool IsPrimary { get; set; }
    }

    public class MyDbContext : DbContext
    {
        public DbSet<Person> Persons { get; set; }

        public DbSet<Hobby> Hobbies { get; set; }

        protected override void OnModelCreating(DbModelBuilder builder)
        {
            builder.Entity<PersonHobbies>()
                .HasKey(ph => new { ph.Person_Id, ph.Hobby_Id });

            builder.Entity<PersonHobbies>()
                .HasRequired(ph => ph.Person)
                .WithMany(ph => ph.Hobbies)
                .HasForeignKey(ph => ph.Person_Id);

            builder.Entity<PersonHobbies>()
                .HasRequired(ph => ph.Hobby)
                .WithMany(ph => ph.Persons)
                .HasForeignKey(ph => ph.Hobby_Id);
        }
    }
}
