﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTableFilter
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> deptList = new List<string>() { "DEPT1", "DEPT3" };
            DataTable dt = PopulateDataTable();

            dt = dt.AsEnumerable()
                .Where(dr => deptList.Contains(dr["DepartmentId"].ToString()))
                .CopyToDataTable();

            foreach (DataRow row in dt.Rows)
            {
                Console.WriteLine(string.Format("{0} {1} is in {2}", row["FirstName"], row["LastName"], row["DepartmentId"]));
            }
            Console.ReadLine();
        }

        static DataTable PopulateDataTable()
        {
            DataTable dtEmployee = new DataTable();
            dtEmployee.Columns.Add("EmpId", typeof(int));
            dtEmployee.Columns.Add("FirstName", typeof(string));
            dtEmployee.Columns.Add("LastName", typeof(string));
            dtEmployee.Columns.Add("DepartmentId", typeof(string));

            dtEmployee.Rows.Add(1, "Jaliya", "Udagedara", "DEPT1");
            dtEmployee.Rows.Add(2, "John", "Doe", "DEPT2");
            dtEmployee.Rows.Add(3, "Jane", "Doe", "DEPT3");
            dtEmployee.Rows.Add(4, "John", "Smith", "DEPT4");
            dtEmployee.Rows.Add(5, "Jane", "Smith", "DEPT1");
            return dtEmployee;
        }
    }
}
