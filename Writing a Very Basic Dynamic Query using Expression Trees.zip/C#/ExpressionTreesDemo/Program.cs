﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ExpressionTreesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> employees = Employee.GetEmployees();
            //var filteredEmployees = employees.Where(e => e.Country == "Sri Lanka");
            //foreach (var item in filteredEmployees)
            //{
            //    Console.WriteLine(item.Name);
            //}

            ParameterExpression pe = Expression.Parameter(typeof(Employee), "e");
            Expression left = Expression.Property(pe, typeof(Employee).GetProperty("Country"));
            Expression right = Expression.Constant("Sri Lanka");
            Expression expression = Expression.Equal(left, right);
            var lambda = Expression.Lambda<Func<Employee, bool>>(expression, pe).Compile();
            var filteredEmployees = employees.Where(lambda);
            foreach (var item in filteredEmployees)
            {
                Console.WriteLine(item.Name);
            }
        }

        public class Employee
        {
            public int EmployeeId { get; set; }
            public string Name { get; set; }
            public string Country { get; set; }

            public static List<Employee> GetEmployees()
            {
                return new List<Employee>()
                {
                    new Employee(){EmployeeId=1,Name="Jaliya Udagedara", Country="Sri Lanka"},
                    new Employee(){EmployeeId=2,Name="John Smith", Country="United States"},
                    new Employee(){EmployeeId=3,Name="Jane Smith", Country="United States"},
                };
            }
        }
    }
}
