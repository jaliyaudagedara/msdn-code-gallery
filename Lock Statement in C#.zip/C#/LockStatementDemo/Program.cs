﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LockStatementDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            MyClass oMyClass = new MyClass();
            List<Thread> threads = new List<Thread>();

            for (int i = 0; i < 5; i++)
            {
                Thread t = new Thread(new ThreadStart(() =>
                {
                    oMyClass.MyMethodWithoutLock();
                    oMyClass.MyMethodWithLock();
                }));
                threads.Add(t);
            }

            foreach (Thread t in threads)
            {
                t.Start();
            }

            Console.WriteLine(DateTime.Now);
        }
    }

    public class MyClass
    {
        private Object thisLock = new Object();

        public void MyMethodWithoutLock()
        {
            Thread.Sleep(5000);
            Console.WriteLine("Without Lock " + DateTime.Now);
        }

        public void MyMethodWithLock()
        {
            lock (thisLock)
            {
                Thread.Sleep(5000);
                Console.WriteLine("With Lock " + DateTime.Now);
            }
        }
    }
}
