﻿using System.Threading.Tasks;
using SQLite;

namespace SQLiteModernApp.DataAccess
{
    public interface IDbConnection
    {
        Task InitializeDatabase();
        SQLiteAsyncConnection GetAsyncConnection();
    }
}
