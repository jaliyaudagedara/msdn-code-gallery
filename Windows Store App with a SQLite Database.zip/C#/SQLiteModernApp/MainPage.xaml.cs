﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using SQLiteModernApp.DataAccess;
using SQLiteModernApp.DataModel;
using SQLiteModernApp.Repository;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace SQLiteModernApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        List<Department> deptList = new List<Department>();

        DepartmentRepository oDepartmentRepository;
        EmployeeRepository oEmployeeRepository;

        Employee employee;

        public MainPage()
        {
            this.InitializeComponent();        
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            await InitializeDatabase();
            await UpdateListView();
            await LoadDepartments();

            btnCreate.IsEnabled = true;
            btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;
        }

        private async Task InitializeDatabase()
        {
            DbConnection oDbConnection = new DbConnection();
            await oDbConnection.InitializeDatabase();
            oDepartmentRepository = new DepartmentRepository(oDbConnection);
            oEmployeeRepository = new EmployeeRepository(oDbConnection);
        }

        private async void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            await oEmployeeRepository.InsertEmployeeAsync(new Employee() { FirstName = txtFirstName.Text, LastName = txtLastName.Text, Email = txtEmail.Text, DepartmentId = Convert.ToInt32(cboDepartment.SelectedValue)});
            await UpdateListView();

            ClearControls();
        }

        private async Task UpdateListView()
        {
            Employee oEmployee = new Employee();
            List<Employee> result = await oEmployeeRepository.SelectAllEmployeesAsync();
            //or parse a query
            //List<Employee> result = await oEmployeeRepository.SelectEmployeesAsync("SELECT EmployeeId, FirstName, LastName, Email, DepartmentId FROM Employee");

            lstViewEmployees.ItemsSource = result;
        }

        private async Task LoadDepartments()
        {
            deptList.Add(new Department { DepartmentId = 1, DepartmentName = "Microsoft Visual Studio" });
            deptList.Add(new Department { DepartmentId = 2, DepartmentName = "Microsoft SQL Server" });
            deptList.Add(new Department { DepartmentId = 3, DepartmentName = "Microsoft Office" });
            deptList.Add(new Department { DepartmentId = 4, DepartmentName = "Microsoft Exchange Server" });

            foreach (Department item in deptList)
            {
                await oDepartmentRepository.InsertDepartmentAsync(item);
            }
            List<Department> result = await oDepartmentRepository.SelectAllDepartmentsAsync();
            cboDepartment.ItemsSource = result;
            cboDepartment.SelectedIndex = 0;
        }

        private void ClearControls()
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtEmail.Text = "";
            cboDepartment.SelectedIndex = 0;

            btnCreate.IsEnabled = true;
            btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;
        }

        private void lstViewEmployees_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0)
                return;
            employee = e.AddedItems[0] as Employee;
            sPanelEmployee.DataContext = employee;

            btnCreate.IsEnabled = false;
            btnUpdate.IsEnabled = true;
            btnDelete.IsEnabled = true;
        }

        private async void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            await oEmployeeRepository.UpdateEmployeeAsync(employee);
            await UpdateListView();
            ClearControls();
        }

        private async void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            await oEmployeeRepository.DeleteEmployeeAsync(employee);
            await UpdateListView();
            ClearControls();
        }
    }
}
