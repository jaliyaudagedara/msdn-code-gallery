﻿using System;
using System.Collections.Generic;
using System.Data.Services.Common;
using System.Linq;
using System.Web;

namespace WCFDataServicesWithReflectionProvider
{
    [DataServiceKeyAttribute("DepartmentId")]
    public class Department
    {
        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; }

        public static List<Department> GetDepartments()
        {
            List<Department> deptList = new List<Department>();
            deptList.Add(new Department() { DepartmentId = 1, DepartmentName = "Information Technology" });
            deptList.Add(new Department() { DepartmentId = 2, DepartmentName = "Finance" });
            deptList.Add(new Department() { DepartmentId = 3, DepartmentName = "Human Resources" });
            return deptList;
        }
    }

    [DataServiceKeyAttribute("JobRoleId")]
    public class JobRole
    {
        public int JobRoleId { get; set; }
        public string JobRoleName { get; set; }

        public static List<JobRole> GetJobRoles()
        {
            List<JobRole> jobRoleList = new List<JobRole>();
            jobRoleList.Add(new JobRole() { JobRoleId = 1, JobRoleName = "Software Engineer" });
            jobRoleList.Add(new JobRole() { JobRoleId = 2, JobRoleName = "Project Manager" });
            jobRoleList.Add(new JobRole() { JobRoleId = 3, JobRoleName = "Accountant" });
            jobRoleList.Add(new JobRole() { JobRoleId = 4, JobRoleName = "HR Executive" });
            return jobRoleList;
        }
    }

    [DataServiceKeyAttribute("EmployeeId")]
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Department Departments { get; set; }
        public List<JobRole> JobRoles { get; set; }

        public static List<Employee> GetEmployees()
        {
            List<Employee> empList = new List<Employee>();
            empList.Add(new Employee()
            {
                EmployeeId = 1,
                FirstName = "Jaliya",
                LastName = "Udagedara",
                Departments = Department.GetDepartments().First(dept => dept.DepartmentName == "Information Technology"),
                JobRoles = new List<JobRole>() 
                { 
                    JobRole.GetJobRoles().First(jobRole => jobRole.JobRoleName == "Software Engineer"),
                    JobRole.GetJobRoles().First(jobRole => jobRole.JobRoleName == "Project Manager") 
                }
            });
            empList.Add(new Employee()
            {
                EmployeeId = 2,
                FirstName = "John",
                LastName = "Doe",
                Departments = Department.GetDepartments().First(dept => dept.DepartmentName == "Finance"),
                JobRoles = new List<JobRole>() 
                { 
                    JobRole.GetJobRoles().First(jobRole => jobRole.JobRoleName == "Accountant") 
                }
            });
            empList.Add(new Employee()
            {
                EmployeeId = 3,
                FirstName = "Jane",
                LastName = "Doe",
                Departments = Department.GetDepartments().First(dept => dept.DepartmentName == "Human Resources"),
                JobRoles = new List<JobRole>() 
                { 
                    JobRole.GetJobRoles().First(jobRole => jobRole.JobRoleName == "HR Executive") 
                }
            });
            return empList;
        }
    }

    public class MyDataContext
    {
        public IQueryable<Employee> Employees
        {
            get
            {
                return Employee.GetEmployees().AsQueryable();
            }
        }

        public IQueryable<Department> Departments
        {
            get
            {
                return Department.GetDepartments().AsQueryable();
            }
        }

        public IQueryable<JobRole> JobRoles
        {
            get
            {
                return JobRole.GetJobRoles().AsQueryable();
            }
        }

        //public List<Department> Departments
        //{
        //    get
        //    {
        //        return Department.GetDepartments();
        //    }
        //}
    }
}