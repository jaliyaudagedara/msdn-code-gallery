﻿
namespace PrismForWinRTDemo.Interfaces
{
    public interface IMainPageViewModel
    {
        string FirstName { get; set; }

        string LastName { get; set; }
    }
}
