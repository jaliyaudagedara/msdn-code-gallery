﻿using PrismForWinRTDemo.Interfaces;

namespace PrismForWinRTDemo.DesignTime
{
    public class MainPageViewModel : IMainPageViewModel
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public MainPageViewModel()
        {
            this.FirstName = "Design time first name";
            this.LastName = "Design time last name";
        }
    }
}
