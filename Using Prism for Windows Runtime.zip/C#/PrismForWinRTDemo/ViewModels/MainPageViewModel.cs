﻿using Microsoft.Practices.Prism.Mvvm;
using PrismForWinRTDemo.Interfaces;
using System.Collections.Generic;
using Windows.UI.Xaml.Navigation;

namespace PrismForWinRTDemo.ViewModels
{
    public class MainPageViewModel : ViewModel, IMainPageViewModel
    {
        private string firstName = default(string);
        public string FirstName
        {
            get
            {
                return firstName;
            }
            set
            {
                SetProperty(ref firstName, value);
            }
        }

        private string lastName = default(string);
        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                SetProperty(ref lastName, value);
            }
        }

        public override void OnNavigatedTo(object navigationParameter, NavigationMode navigationMode, Dictionary<string, object> viewModelState)
        {
            this.FirstName = "Jaliya";
            this.LastName = "Udagedara";
        }
    }
}
