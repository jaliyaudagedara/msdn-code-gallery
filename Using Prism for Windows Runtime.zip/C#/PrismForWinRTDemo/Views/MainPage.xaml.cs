﻿using Microsoft.Practices.Prism.StoreApps;

namespace PrismForWinRTDemo.Views
{
    public sealed partial class MainPage : VisualStateAwarePage
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
    }
}
