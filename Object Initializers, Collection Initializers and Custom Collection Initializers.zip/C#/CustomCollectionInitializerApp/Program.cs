﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace CustomCollectionInitializerApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //EmployeeCollection employees = new EmployeeCollection();
            //employees.Add(1, "Jaliya Udagedara");

            EmployeeCollection employees = new EmployeeCollection()
            {
                {1, "Jaliya Udagedara"}
            };

            foreach (var item in employees)
            {
                Console.WriteLine(item.Name);
            }
        }
    }

    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Employee(int id, string name)
        {
            Id = id;
            Name = name;
        }
    }

    public class EmployeeCollection : IEnumerable<Employee>
    {
        private readonly List<Employee> employees;

        public EmployeeCollection()
        {
            employees = new List<Employee>();
        }

        public void Add(int id, string name)
        {
            employees.Add(new Employee(id, name));
        }

        public IEnumerator<Employee> GetEnumerator()
        {
            return employees.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}