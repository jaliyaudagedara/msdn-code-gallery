﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCodeFirstForeignKeysDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            using (MyContext context = new MyContext())
            {
                context.Departments.Add(new Department() { DepartmentName = "Microsoft Visual Studio" });
                context.SaveChanges();
            }
        }
    }

    public class Department
    {
        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; }
    }

    public class Employee
    {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int DepartmentId { get; set; }
        public Department Department { get; set; }
    }

    public class MyContext : DbContext
    {
        public DbSet<Department> Departments { get; set; }
        public DbSet<Employee> Employees { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            modelBuilder.Entity<Employee>()
                .HasRequired(e => e.Department)
                .WithMany()
                .HasForeignKey(e => e.DepartmentId); 
        }
    }
}
