﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFLoadingApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //AddData();

            using (MyContext context = new MyContext())
            {
                //// initial query which will throw me the error
                //foreach (Employee employee in context.Employees)
                //{
                //    Console.WriteLine(employee.FirstName + "-"
                //        + employee.Department.DepartmentName);
                //}

                //Console.ReadLine();

                // start eagerly loading
                // eagerly loading department of the employee
                Console.WriteLine("---eagerly loading department of the employee---\n");
                var employees = context.Employees.Include(e => e.Department).ToList();
                // or
                //var employees = context.Employees.Include("Department").ToList();

                foreach (Employee employee in employees)
                {
                    Console.WriteLine(employee.FirstName + "-"
                        + employee.Department.DepartmentName);
                }
                Console.WriteLine("\n---end eagerly loading department of the employee---\n");

                // eagerly loading employees of the department
                Console.WriteLine("---eagerly loading employees of the department---\n");
                var departments = context.Departments.Include(d => d.Employees).ToList();
                // or
                //var departments = context.Departments.Include("Employees").ToList();

                foreach (Department department in departments)
                {
                    Console.WriteLine(department.DepartmentName);
                    Console.WriteLine("------------------");
                    foreach (Employee employee in department.Employees)
                    {
                        Console.WriteLine(employee.FirstName);
                    }
                    Console.WriteLine("------------------");
                }
                Console.WriteLine("\n---end eagerly loading employees of the department---\n");
                // end eagerly loading

                Console.ReadLine();

                // start explicit loading
                // explicit loading department of the employee
                Console.WriteLine("---explicit reference for loading department of the employee ---\n");
                foreach (Employee employee in context.Employees)
                {
                    context.Entry(employee).Reference(e => e.Department).Load();
                    // or
                    //context.Entry(employee).Reference("Department").Load();

                    Console.WriteLine(employee.FirstName + "-"
                        + employee.Department.DepartmentName);
                }
                Console.WriteLine("\n---end explicit reference for loading department of the employee ---\n");

                // explicit loading employees of the department
                Console.WriteLine("---explicit collection for loading employees of the department---\n");
                foreach (Department department in context.Departments)
                {
                    context.Entry(department).Collection(d => d.Employees).Load();
                    // or
                    //context.Entry(department).Collection("Employees").Load();

                    Console.WriteLine(department.DepartmentName);
                    Console.WriteLine("------------------");
                    foreach (Employee employee in department.Employees)
                    {
                        Console.WriteLine(employee.FirstName);
                    }
                    Console.WriteLine("------------------");
                }
                Console.WriteLine("\n---end explicit collection for loading employees of the department---\n");
                // end explicit loading

                Console.ReadLine();

                //// start lazy loading -> put virtual on navigation property
                ////context.Configuration.LazyLoadingEnabled = false;

                //foreach (Employee employee in context.Employees)
                //{
                //    Console.WriteLine(employee.FirstName + "-"
                //        + employee.Department.DepartmentName);
                //}
                //// end lazy loading

                //Console.ReadLine();
            }
        }

        static void AddData()
        {
            using (MyContext context = new MyContext())
            {
                foreach (var department in Department.GetDepartments())
                {
                    context.Departments.Add(department);
                }
                context.SaveChanges();

                foreach (var employee in Employee.GetEmployees())
                {
                    employee.Department = context.Departments.
                        First(d => d.DepartmentId == employee.Department.DepartmentId);
                    context.Employees.Add(employee);
                }
                context.SaveChanges();
            }
        }
    }

    public class Department
    {
        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; }
        public ICollection<Employee> Employees { get; set; }

        public static List<Department> GetDepartments()
        {
            return new List<Department>()
            {
                new Department()
                {
                    DepartmentId=1,
                    DepartmentName="Microsoft Visual Studio"
                },
                new Department()
                {
                    DepartmentId=2,
                    DepartmentName="Microsoft SQL Server"
                }
            };
        }
    }

    public class Employee
    {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Department Department { get; set; }

        public static List<Employee> GetEmployees()
        {
            return new List<Employee>()
            {
                new Employee()
                {
                    EmployeeId=1,
                    FirstName="Jaliya",
                    LastName="Udagedara",
                    Department=Department.GetDepartments().First(d=>d.DepartmentId==1)
                },
                new Employee()
                {
                    EmployeeId=2,
                    FirstName="John",
                    LastName="Smith",
                    Department=Department.GetDepartments().First(d=>d.DepartmentId==2)
                },
                new Employee()
                {
                    EmployeeId=3,
                    FirstName="Gary",
                    LastName="Smith",
                    Department=Department.GetDepartments().First(d=>d.DepartmentId==1)
                }
            };
        }
    }

    public class MyContext : DbContext
    {
        public DbSet<Department> Departments { get; set; }
        public DbSet<Employee> Employees { get; set; }
    }
}
