﻿using System;
using WcfDataServicesDemo_Client.NorthwindService;

namespace WcfDataServicesDemo_Client
{
    class Program
    {
        static void Main(string[] args)
        {
            NorthwindEntities context = new NorthwindEntities(new Uri("http://localhost:8555/NorthwindService.svc/"));

            //// 1
            //var employees = from e in context.Employees
            //                where e.FirstName.StartsWith("A")
            //                select e;

            //// 2
            //var employees = context.Employees.AddQueryOption("$filter", "startswith(FirstName,'A')");

            //// 3
            //var employees = context.Execute<Employee>(new Uri("Employees()?$filter=startswith(FirstName,'A')", UriKind.Relative));

            // 4
            var employees = context.CreateQuery<Employee>("GetEmployeesByFirstNameStartingWith").AddQueryOption("firstName", "'A'");

            foreach (var item in employees)
            {
                Console.WriteLine(item.FirstName);
            }
        }
    }
}
