﻿using System.Collections.Generic;
using System.Data.Services.Common;

namespace WcfDataServicesDemo_ReflectionProvider
{
    [DataServiceKey("Id")]
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public static List<Employee> GetEmployees()
        {
            return new List<Employee>()
            {
                new Employee() { Id = 1, Name = "Jaliya Udagedara" },
                new Employee() { Id = 2, Name = "Jane Smith" },
            };
        }
    }
}
