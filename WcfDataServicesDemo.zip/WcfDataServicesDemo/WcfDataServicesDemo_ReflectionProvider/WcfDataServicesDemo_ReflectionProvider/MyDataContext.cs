﻿using System.Linq;

namespace WcfDataServicesDemo_ReflectionProvider
{
    public class MyDataContext
    {
        public IQueryable<Employee> Employees
        {
            get
            {
                return Employee.GetEmployees().AsQueryable();
            }
        }
    }
}
