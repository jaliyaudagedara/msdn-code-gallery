using System.Data.Services;
using System.Data.Services.Common;
using System.Data.Services.Providers;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace WcfDataServicesDemo_EfProvider
{
    [ServiceBehavior(IncludeExceptionDetailInFaults = true)]
    public class NorthwindService : EntityFrameworkDataService<NorthwindEntities>
    {
        public static void InitializeService(DataServiceConfiguration config)
        {
            config.SetEntitySetAccessRule("*", EntitySetRights.AllRead);
            config.SetServiceOperationAccessRule("*", ServiceOperationRights.All);
            config.DataServiceBehavior.MaxProtocolVersion = DataServiceProtocolVersion.V3;
            config.UseVerboseErrors = true;
        }

        [WebGet]
        public IQueryable<Employee> GetEmployeesByFirstNameStartingWith(string firstName)
        {
            NorthwindEntities context = new NorthwindEntities();
            return context.Employees.Where(e => e.FirstName.StartsWith(firstName));
        }
    }
}
