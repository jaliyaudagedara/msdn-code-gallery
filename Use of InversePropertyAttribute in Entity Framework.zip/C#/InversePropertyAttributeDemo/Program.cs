﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace InversePropertyAttributeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            using (MyDbContext context = new MyDbContext())
            {
                Database.SetInitializer<MyDbContext>(new DropCreateDatabaseAlways<MyDbContext>());
                context.Hobbies.Add(new Hobby() { Name = "Programming" });
                context.Hobbies.Add(new Hobby() { Name = "Listening to music" });
                context.SaveChanges();

                context.People.Add(new Person()
                {
                    Name = "Jaliya Udagedara",
                    PrimaryHobby = context.Hobbies.First(h => h.Name == "Programming"),
                    SecondaryHobby = context.Hobbies.First(h => h.Name == "Listening to music")
                });

                context.People.Add(new Person()
                {
                    Name = "John Smith",
                    PrimaryHobby = context.Hobbies.First(h => h.Name == "Listening to music"),
                    SecondaryHobby = context.Hobbies.First(h => h.Name == "Programming")
                });

                context.SaveChanges();

                Hobby hobby = context.Hobbies.First(h => h.Name == "Programming");
                foreach (var item in hobby.People)
                {
                    Console.WriteLine(item.Name);
                }
            }
        }
    }

    public class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
        //[InverseProperty("People")]
        public virtual Hobby PrimaryHobby { get; set; }
        public virtual Hobby SecondaryHobby { get; set; }
    }

    public class Hobby
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public virtual List<Person> People { get; set; }
    }

    public class MyDbContext : DbContext
    {
        public DbSet<Person> People { get; set; }
        public DbSet<Hobby> Hobbies { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Person>()
                .HasOptional(a => a.PrimaryHobby)
                .WithMany(b => b.People);
        }
    }
}
