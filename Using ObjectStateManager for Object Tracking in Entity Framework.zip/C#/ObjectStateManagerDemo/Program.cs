﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Data.Entity.Core;
using System.Data.Entity.Core.Common;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Core.Objects.DataClasses;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectStateManagerDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            using (MyContext context = new MyContext())
            {
                ////foreach (var item in Hobby.GetHobbies())
                ////{
                ////    context.Hobbies.Add(item);
                ////}

                ////foreach (var item in Department.GetDepartments())
                ////{
                ////    context.Departments.Add(item);
                ////}

                ////context.SaveChanges();

                ////context.People.Add(new Person()
                ////    {
                ////        Id = 1,
                ////        Name = "Jaliya Udagedara",
                ////        Department = context.Departments.First(d => d.Id == 1),
                ////        Hobbies = new List<Hobby>()
                ////        {
                ////            context.Hobbies.First( h => h.Id == 1),
                ////            context.Hobbies.First( h => h.Id == 2),
                ////        }
                ////    });

                ////context.SaveChanges();

                // adding a new item
                context.Departments.Add(new Department() { Id = 3, Name = "Microsoft SQL Server" });

                // updating simple property of an existing item
                context.People.First(p => p.Id == 1).Name = "Jaliya Bandara Udagedara";

                // updating complex property of an existing item
                context.People.First(p => p.Id == 1).Department = context.Departments.First(d => d.Id == 2);

                // adding item to a collection type property of an existing item
                context.People.First(p => p.Id == 1).Hobbies.Add(context.Hobbies.First(h => h.Id == 3));

                // removing item to a collection type property of an existing item
                context.People.First(p => p.Id == 1).Hobbies.Remove(context.Hobbies.First(h => h.Id == 2));

                // deleting an existing item
                context.Hobbies.Remove(context.Hobbies.First(h => h.Id == 4));

                // let's see what the changes are
                DetectChanges(context);
                //context.SaveChanges();
            }

            Console.ReadLine();
        }

        private static void DetectChanges(MyContext context)
        {
            ((IObjectContextAdapter)context).ObjectContext.DetectChanges();
            ObjectStateManager objectStateManager = ((IObjectContextAdapter)context).ObjectContext.ObjectStateManager;

            IEnumerable<ObjectStateEntry> addedEntries = objectStateManager.GetObjectStateEntries(EntityState.Added);
            IEnumerable<ObjectStateEntry> modifiedEntries = objectStateManager.GetObjectStateEntries(EntityState.Modified);
            IEnumerable<ObjectStateEntry> deletedEntries = objectStateManager.GetObjectStateEntries(EntityState.Deleted);

            foreach (ObjectStateEntry entry in addedEntries)
            {
                LogAddedEntries(entry);
            }

            foreach (ObjectStateEntry entry in modifiedEntries)
            {
                LogModifiedEntries(entry);
            }

            foreach (ObjectStateEntry entry in deletedEntries)
            {
                LogDeletedEntries(entry);
            }
        }

        private static void LogAddedEntries(ObjectStateEntry entry)
        {
            if (entry.IsRelationship) //relationship added
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine(string.Format("Adding relationship to : {0}", entry.EntitySet.Name));
                sb.AppendLine();

                var currentValues = entry.CurrentValues;
                for (var i = 0; i < currentValues.FieldCount; i++)
                {
                    string fName = currentValues.DataRecordInfo.FieldMetadata[i].FieldType.Name;
                    EntityKey fCurrVal = (EntityKey)currentValues[i];

                    sb.AppendLine(string.Format("Table : {0}", fName));
                    sb.AppendLine(string.Format("Property Name: {0}", fCurrVal.EntitySetName));
                    sb.AppendLine(string.Format("Id : {0}", fCurrVal.EntityKeyValues[0].Value));
                }

                Console.WriteLine(sb.ToString());
                Console.WriteLine("--------------------------------------------");
            }
            else //item added
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine(string.Format("Adding new item to : {0}", entry.EntitySet.Name));
                sb.AppendLine();

                var currentValues = entry.CurrentValues;
                for (var i = 0; i < currentValues.FieldCount; i++)
                {
                    string fName = currentValues.DataRecordInfo.FieldMetadata[i].FieldType.Name;
                    var fCurrVal = currentValues[i];

                    sb.AppendLine(string.Format("Property Name : {0}", fName));
                    sb.AppendLine(string.Format("Property Value : {0}", fCurrVal));
                }

                Console.WriteLine(sb.ToString());
                Console.WriteLine("--------------------------------------------");
            }
        }

        private static void LogModifiedEntries(ObjectStateEntry entry)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(string.Format("Modifying properties in : {0}", entry.EntitySet.Name));
            sb.AppendLine();

            var properties = entry.GetModifiedProperties();

            for (int i = 0; i < properties.Count(); i++)
            {
                string propertyName = properties.ToArray()[i];
                string OriginalValue = entry.OriginalValues.GetValue(entry.OriginalValues.GetOrdinal(propertyName)).ToString();
                string CurrentValue = entry.CurrentValues.GetValue(entry.CurrentValues.GetOrdinal(propertyName)).ToString();

                sb.AppendLine(string.Format("Property Name : {0}", propertyName));
                sb.AppendLine(string.Format("Original Value : {0}", OriginalValue));
                sb.AppendLine(string.Format("Current Value : {0}", CurrentValue));
            }

            Console.WriteLine(sb.ToString());
            Console.WriteLine("--------------------------------------------");
        }

        private static void LogDeletedEntries(ObjectStateEntry entry)
        {
            if (entry.IsRelationship) //relationship deleted
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine(string.Format("Deleting relationship from : {0}", entry.EntitySet.Name));
                sb.AppendLine();

                var originalValues = entry.OriginalValues;

                for (var i = 0; i < originalValues.FieldCount; i++)
                {
                    EntityKey fCurrVal = (EntityKey)entry.OriginalValues.GetValue(i);

                    sb.AppendLine(string.Format("Property Name : {0}", fCurrVal.EntitySetName));
                    sb.AppendLine(string.Format("Property Value : {0}", fCurrVal.EntityKeyValues[0]));
                }

                Console.WriteLine(sb.ToString());
                Console.WriteLine("--------------------------------------------");
            }
            else //entry deleted
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine(string.Format("Deleting item from : {0}", entry.EntitySet.Name));
                sb.AppendLine();

                var originalValues = entry.OriginalValues;

                for (var i = 0; i < originalValues.FieldCount; i++)
                {
                    var fCurrVal = entry.OriginalValues.GetValue(i);
                    sb.AppendLine(string.Format("Data : {0}", fCurrVal));
                }

                Console.WriteLine(sb.ToString());
                Console.WriteLine("--------------------------------------------");
            }
        }
    }

    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public virtual List<Person> People { get; set; }

        public static List<Department> GetDepartments()
        {
            return new List<Department>()
            {
                new Department() 
                {
                    Id = 1,
                    Name = "Visual C#"
                },
                new Department() 
                {
                    Id = 2,
                    Name = "Microsoft Visual Studio"
                },
            };
        }
    }

    public class Hobby
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public virtual List<Person> People { get; set; }

        public static List<Hobby> GetHobbies()
        {
            return new List<Hobby>()
            {
                new Hobby() { Id = 1, Name = "Programming." },
                new Hobby() { Id = 2, Name = "Reading books." },
                new Hobby() { Id = 3, Name = "Listening to music." },
                new Hobby() { Id = 4, Name = "Watching movies." },
            };
        }
    }

    public class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public virtual List<Hobby> Hobbies { get; set; }
        public virtual Department Department { get; set; }
    }

    public class MyContext : DbContext
    {
        public DbSet<Department> Departments { get; set; }
        public DbSet<Hobby> Hobbies { get; set; }
        public DbSet<Person> People { get; set; }
    }
}
