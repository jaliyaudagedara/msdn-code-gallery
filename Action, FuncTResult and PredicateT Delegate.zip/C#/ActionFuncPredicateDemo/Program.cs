﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActionFuncPredicateDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> employees = Employee.GetEmployeees();

            //// Action ////

            //Action<Employee> empAction = new Action<Employee>(CalculateAge);
            //employees.ForEach(empAction);

            employees.ForEach(e => e.Age = DateTime.Now.Year - e.Birthday.Year);
            foreach (Employee e in employees)
            {
                Console.WriteLine(e.Age);
            }

            //// end Action ////

            //// Func ////

            //Func<Employee, bool> myFunc = new Func<Employee, bool>(NameIsEqual);
            //Console.WriteLine(employees.First(myFunc).FirstName);

            Console.WriteLine(employees.First(e => e.FirstName == "Jaliya").FirstName);

            //// end Func ////

            //// Predicate ////

            //Predicate<Employee> predicate = new Predicate<Employee>(BornInNinteenEightySix);
            //Console.WriteLine(employees.Find(predicate).FirstName);

            Console.WriteLine(employees.Find(e => e.Birthday.Year == 1986).FirstName);

            //// end Predicate ////

            //// Func vs Predicate
            Func<int, string> myFunc = new Func<int, string>(MyMethod);
            Console.WriteLine(myFunc(3));

            //Predicate<int> myPredicate = new Predicate<int>(MyMethod);
        }

        static string MyMethod(int i)
        {
            return "You entered: " + i;
        }

        static void CalculateAge(Employee emp)
        {
            emp.Age = DateTime.Now.Year - emp.Birthday.Year;
        }

        static bool NameIsEqual(Employee emp)
        {
            return emp.FirstName == "Jaliya";
        }

        static bool BornInNinteenEightySix(Employee emp)
        {
            return emp.Birthday.Year == 1986;
        }
    }

    public class Employee
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime Birthday { get; set; }
        public int Age { get; set; }

        public static List<Employee> GetEmployeees()
        {
            return new List<Employee>()
            {
                new Employee()
                {
                    FirstName = "Jaliya",
                    LastName = "Udagedara",
                    Birthday =  Convert.ToDateTime("1986-09-11")
                },
                new Employee()
                {
                    FirstName = "Gary",
                    LastName = "Smith",
                    Birthday = Convert.ToDateTime("1988-03-20")
                }
            };
        }
    }
}
