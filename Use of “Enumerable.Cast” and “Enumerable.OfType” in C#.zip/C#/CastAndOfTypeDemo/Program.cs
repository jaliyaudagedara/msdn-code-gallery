﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastAndOfTypeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList oArrayList = GetData();

            #region using Enumerable.Cast<TResult> Method

            //// explicitly declaring the type of the range variable
            //var query = from Employee e in oArrayList
            //            where e.FullName.StartsWith("J")
            //            select e;

            //// query syntax
            //var query = from e in oArrayList.Cast<Employee>()
            //            where e.FullName.StartsWith("J")
            //            select e;

            //// method syntax
            //var query = oArrayList.Cast<Employee>()
            //    .Where(e => e.FullName.StartsWith("J"));

            //foreach (var item in query)
            //{
            //    Console.WriteLine(item.FullName);
            //}

            #endregion

            #region using Enumerable.OfType<TResult> Method

            #region oArrayList.OfType<string>

            //// query syntax
            //IEnumerable<string> query = from s in oArrayList.OfType<string>()
            //                            where s.StartsWith("J")
            //                            select s;

            //// method syntax
            //IEnumerable<string> query = oArrayList.OfType<string>()
            //                                .Where(s => s.StartsWith("J"));

            //foreach (var item in query)
            //{
            //    Console.WriteLine(item);
            //}

            #endregion oArrayList.OfType<string>

            #region oArrayList.OfType<List<string>

            //// query syntax
            //IEnumerable<List<string>> query = from l in oArrayList.OfType<List<string>>()
            //                                  where l.Contains("VS")
            //                                  select l;

            //// method syntax
            //IEnumerable<List<string>> query = oArrayList.OfType<List<string>>()
            //                                    .Where(l => l.Contains("VS"));

            //foreach (var item in query)
            //{
            //    Console.WriteLine(item.Last());
            //}

            #endregion oArrayList.OfType<List<string>

            #region oArrayList.OfType<Employee>

            //// query syntax
            //IEnumerable<Employee> query = from e in oArrayList.OfType<Employee>()
            //                              where e.FullName.StartsWith("J")
            //                              select e;

            // method syntax
            IEnumerable<Employee> query = oArrayList.OfType<Employee>()
                                            .Where(e => e.FullName.StartsWith("J"));

            foreach (var item in query)
            {
                Console.WriteLine(item.FullName);
            }

            #endregion oArrayList.OfType<Employee>

            #endregion using Enumerable.OfType<TResult> Method
        }

        static ArrayList GetData()
        {
            ArrayList oArrayList = new ArrayList()
            {
                "Jaliya",
                "Smith",
                10,
                20,
                new List<string>() { "VS", "SQL" },
                new List<string>() { "VS", "Windows Azure" },
                new List<string>() { "Apple", "Orange" },
                new Employee()
                {
                    EmployeeId=1,FullName="Jaliya Udagedara"
                },
                new Employee()
                {
                    EmployeeId=2,FullName="Martin Smith"
                }
            };
            return oArrayList;
        }
    }

    public class Employee
    {
        public int EmployeeId { get; set; }
        public string FullName { get; set; }
    }
}
