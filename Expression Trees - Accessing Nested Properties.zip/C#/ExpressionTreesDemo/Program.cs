﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ExpressionTreesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //IEnumerable<Employee> employees = Employee.GetEmployees().Where(e => e.Department.DepartmentId == 1);

            //foreach (var item in employees)
            //{
            //    Console.WriteLine(item.Name);
            //}

            ParameterExpression pe = Expression.Parameter(typeof(Employee), "e");
            Expression left = Expression.Property(pe, typeof(Employee).GetProperty("Department"));
            left = Expression.Property(left, typeof(Department).GetProperty("DepartmentId"));
            Expression right = Expression.Constant(1, typeof(int));
            Expression expression = Expression.Equal(left, right);
            var lambda = Expression.Lambda<Func<Employee, bool>>(expression, pe).Compile();
            IEnumerable<Employee> employees = Employee.GetEmployees().Where(lambda);

            foreach (var item in employees)
            {
                Console.WriteLine(item.Name);
            }
        }
    }
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public virtual Department Department { get; set; }

        public static List<Employee> GetEmployees()
        {
            return new List<Employee>()
            {
                new Employee()
                {
                    EmployeeId=1,
                    Name="Jaliya Udagedara",
                    Department = Department.GetDepartments().First(d=>d.DepartmentId==1)
                },
                new Employee()
                {
                    EmployeeId=1,
                    Name="John Smith",
                    Department = Department.GetDepartments().First(d=>d.DepartmentId==2)
                },
                new Employee()
                {
                    EmployeeId=1,
                    Name="Jane Smith",
                    Department = Department.GetDepartments().First(d=>d.DepartmentId==1)
                }
            };
        }
    }

    public class Department
    {
        public int DepartmentId { get; set; }
        public string Name { get; set; }

        public static List<Department> GetDepartments()
        {
            return new List<Department>()
            {
                new Department(){DepartmentId=1,Name="Microsoft Visual Studio"},
                new Department(){DepartmentId=2,Name="Microsoft SQL Server"}
            };
        }
    }
}
