﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace IEnumerableVsIQueryableDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DemoDBEntities oDemoDBEntities = new DemoDBEntities();
            CallWithIEnumerable(oDemoDBEntities);
            CallWithIQueryable(oDemoDBEntities);
            Console.ReadLine();
        }

        static void CallWithIEnumerable(DemoDBEntities oDemoDBEntities)
        {
            IEnumerable<Employee> employeeList = 
                oDemoDBEntities.Employees.Where(e => e.LastName == "Smith");
            employeeList = employeeList.Take(1);

            foreach (Employee employee in employeeList)
            {
                Console.WriteLine(employee.FirstName);
            }
        }

        static void CallWithIQueryable(DemoDBEntities oDemoDBEntities)
        {
            IQueryable<Employee> employeeList = 
                oDemoDBEntities.Employees.Where(e => e.LastName == "Smith");
            employeeList = employeeList.Take(1);

            foreach (Employee employee in employeeList)
            {
                Console.WriteLine(employee.FirstName);
            }
        }
    }
}
