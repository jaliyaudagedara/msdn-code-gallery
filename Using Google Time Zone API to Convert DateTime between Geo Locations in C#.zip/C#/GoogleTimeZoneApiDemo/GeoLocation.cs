﻿
namespace GoogleTimeZoneApiDemo
{
    class GeoLocation
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
