
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 08/08/2013 21:42:36
-- Generated from EDMX file: C:\Users\Jaliya Udagedara\Desktop\WCFDataServicesWithEFProvider\WCFDataServicesWithEFProvider\Model1.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [EFProviderDB];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Employees'
CREATE TABLE [dbo].[Employees] (
    [EmployeeId] int IDENTITY(1,1) NOT NULL,
    [FirstName] nvarchar(max)  NOT NULL,
    [LastName] nvarchar(max)  NOT NULL,
    [Department_DepartmentId] int  NOT NULL
);
GO

-- Creating table 'Departments'
CREATE TABLE [dbo].[Departments] (
    [DepartmentId] int IDENTITY(1,1) NOT NULL,
    [DepartmentName] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'JobRoles'
CREATE TABLE [dbo].[JobRoles] (
    [JobRoleId] int IDENTITY(1,1) NOT NULL,
    [JobRoleDesc] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'EmployeeJobRole'
CREATE TABLE [dbo].[EmployeeJobRole] (
    [Employees_EmployeeId] int  NOT NULL,
    [JobRoles_JobRoleId] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [EmployeeId] in table 'Employees'
ALTER TABLE [dbo].[Employees]
ADD CONSTRAINT [PK_Employees]
    PRIMARY KEY CLUSTERED ([EmployeeId] ASC);
GO

-- Creating primary key on [DepartmentId] in table 'Departments'
ALTER TABLE [dbo].[Departments]
ADD CONSTRAINT [PK_Departments]
    PRIMARY KEY CLUSTERED ([DepartmentId] ASC);
GO

-- Creating primary key on [JobRoleId] in table 'JobRoles'
ALTER TABLE [dbo].[JobRoles]
ADD CONSTRAINT [PK_JobRoles]
    PRIMARY KEY CLUSTERED ([JobRoleId] ASC);
GO

-- Creating primary key on [Employees_EmployeeId], [JobRoles_JobRoleId] in table 'EmployeeJobRole'
ALTER TABLE [dbo].[EmployeeJobRole]
ADD CONSTRAINT [PK_EmployeeJobRole]
    PRIMARY KEY NONCLUSTERED ([Employees_EmployeeId], [JobRoles_JobRoleId] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [Department_DepartmentId] in table 'Employees'
ALTER TABLE [dbo].[Employees]
ADD CONSTRAINT [FK_EmployeeDepartment]
    FOREIGN KEY ([Department_DepartmentId])
    REFERENCES [dbo].[Departments]
        ([DepartmentId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_EmployeeDepartment'
CREATE INDEX [IX_FK_EmployeeDepartment]
ON [dbo].[Employees]
    ([Department_DepartmentId]);
GO

-- Creating foreign key on [Employees_EmployeeId] in table 'EmployeeJobRole'
ALTER TABLE [dbo].[EmployeeJobRole]
ADD CONSTRAINT [FK_EmployeeJobRole_Employee]
    FOREIGN KEY ([Employees_EmployeeId])
    REFERENCES [dbo].[Employees]
        ([EmployeeId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [JobRoles_JobRoleId] in table 'EmployeeJobRole'
ALTER TABLE [dbo].[EmployeeJobRole]
ADD CONSTRAINT [FK_EmployeeJobRole_JobRole]
    FOREIGN KEY ([JobRoles_JobRoleId])
    REFERENCES [dbo].[JobRoles]
        ([JobRoleId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_EmployeeJobRole_JobRole'
CREATE INDEX [IX_FK_EmployeeJobRole_JobRole]
ON [dbo].[EmployeeJobRole]
    ([JobRoles_JobRoleId]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------